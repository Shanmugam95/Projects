1.To add a new account:
  http://localhost:8080/api/addAccount
  POST request:
  {
        "accountType": "CR",
        "accountHolderName": "Mukesh Ambani",
        "branchName": "Dharavi",
        "currentBalance": 155891.46,
        "customer": {
            "customerName": "Mukesh Ambani",
            "phoneNumber": "+91 432 8876 542",
            "emailAddress": "ambani.mukesh@relianceltd.com",
            "age": "52",
            "occupation": "Private"
        }
    }

2.To fetch all the account details present:
  http://localhost:8080/api/accounts
  GET request.

3.To update personal details for a particular customer
  http://localhost:8080/api/updateCustomerInfo
  PUT request:
  {
    "accountNumber": "8721409149",
    "customer": {
            "accountNumber": "8721409149",
            "customerName": "Mukesh Ambani",
            "phoneNumber": "+91 44 5674 3401",
            "emailAddress": "ambani.mukesh@relianceltd.com",
            "age": "52",
            "occupation": "Private"
        }
  }

4.To transfer amount between accounts
  http://localhost:8080/api/transferFunds
  POST request:
  {
    "sourceAccount": "7308463591",
    "destinationAccount":"2195620473",
    "amount": 5000.00
  }