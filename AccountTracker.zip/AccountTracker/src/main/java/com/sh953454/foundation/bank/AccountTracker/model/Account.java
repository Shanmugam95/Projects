package com.sh953454.foundation.bank.AccountTracker.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Account",schema="bank_details")

//@SequenceGenerator(name = "account_seq", sequenceName = "account_sequence", schema = "online_bank", initialValue = 5)
public class Account implements Serializable {

private static final long serialVersionUID = 3490746854626737057L;
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
long id;

private String accountNumber;

private String accountType;
 
private String accountHolderName;
 
private String branchName;

private double currentBalance;

private transient Customer customer;

public long getId() {
	return id;
}

public void setId(long id) {
	this.id = id;
}

public String getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}

public String getAccountType() {
	return accountType;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}

public String getAccountHolderName() {
	return accountHolderName;
}

public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}

public String getBranchName() {
	return branchName;
}

public void setBranchName(String branchName) {
	this.branchName = branchName;
}

public double getCurrentBalance() {
	return currentBalance;
}

public void setCurrentBalance(double currentBalance) {
	this.currentBalance = currentBalance;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

}
