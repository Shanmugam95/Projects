package com.sh953454.foundation.bank.AccountTracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccountTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccountTrackerApplication.class, args);
	}

}
