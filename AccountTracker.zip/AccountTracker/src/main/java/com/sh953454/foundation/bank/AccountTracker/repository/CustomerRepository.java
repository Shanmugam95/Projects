package com.sh953454.foundation.bank.AccountTracker.repository;

import org.springframework.data.repository.CrudRepository;

import com.sh953454.foundation.bank.AccountTracker.model.Customer;

public interface CustomerRepository extends CrudRepository<Customer,Long> {
	Customer findById(long id);
	Customer findByAccountNumber(String accountNumber);
}
