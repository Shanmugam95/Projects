package com.sh953454.foundation.bank.AccountTracker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sh953454.foundation.bank.AccountTracker.model.Account;
import com.sh953454.foundation.bank.AccountTracker.model.Customer;
import com.sh953454.foundation.bank.AccountTracker.repository.AccountRepository;
import com.sh953454.foundation.bank.AccountTracker.repository.CustomerRepository;

@Service
public class AccountService {

	@Autowired
	AccountRepository accountRepo;
	
	@Autowired
	CustomerRepository customerRepo;
	
	public Account addAccount(Account newAccount) {
		String acc ="";
		if(newAccount.getAccountNumber()==null) {
			List<Account> accountList = (List<Account>) accountRepo.findAll();
			boolean flag = false;
			do {
			long num = (long) (Math.random()*10000000000L);
			acc =  String.valueOf(num);
			for(Account acct:accountList) {
				if(acc.equals(acct.getAccountNumber())) {
					flag=true;
					break;
				}
			}
			}while(flag);
			newAccount.setAccountNumber(acc);
			newAccount.getCustomer().setAccountNumber(acc);
			accountRepo.save(newAccount);
			customerRepo.save(newAccount.getCustomer());
		}
		return newAccount;
	}
	
	public List<Account> getAllAccount(){
		List<Account> accountList =  (List<Account>) accountRepo.findAll();
		accountList.forEach(account-> account.setCustomer(customerRepo.findByAccountNumber(account.getAccountNumber())));
		return accountList;
	}
	
	public Customer updateCustomer(Account accBean) {
		Customer dbCustomer = customerRepo.findByAccountNumber(accBean.getAccountNumber());
		if(dbCustomer!=null) {
			if(accBean.getCustomer().getEmailAddress()!=null) {
				dbCustomer.setEmailAddress(accBean.getCustomer().getEmailAddress());
			}
			if(accBean.getCustomer().getAge()!=null) {
				dbCustomer.setAge(accBean.getCustomer().getAge());
			}
			if(accBean.getCustomer().getPhoneNumber()!=null) {
				dbCustomer.setPhoneNumber(accBean.getCustomer().getPhoneNumber());
			}
			if(accBean.getCustomer().getOccupation()!=null) {
				dbCustomer.setOccupation(accBean.getCustomer().getOccupation());
			}
			customerRepo.save(dbCustomer);
		}
		return dbCustomer;
	}
	
	public String transferAmount(String source, String destination, double amount) {
		String message = "TRANSACTION SUCCESSFUL";
		Account srcAccount = accountRepo.findByAccountNumber(source);
		Account destAccount = accountRepo.findByAccountNumber(destination);
		if(srcAccount!=null && destAccount!=null) {
			if(isAmountAvailable(srcAccount.getCurrentBalance(),amount)) {
				updateAccountBalance(srcAccount,destAccount,amount);
			}
			else {
				message = "INSUFFICIENT FUNDS";
			}
		}
		else {
			message = "INVALID ACCOUNT";
		}
		return message;
	}
	
	public boolean isAmountAvailable(double balance,double transferAmt) {
		return balance-transferAmt>0;
	}
	
	public void updateAccountBalance(Account srcAccount, Account destAccount, double transferAmt) {
		double srcBalance = srcAccount.getCurrentBalance() - transferAmt;
		srcAccount.setCurrentBalance(srcBalance);
		accountRepo.save(srcAccount);
		double destBalance = destAccount.getCurrentBalance() + transferAmt;
		destAccount.setCurrentBalance(destBalance);
		accountRepo.save(destAccount);
	}
}
