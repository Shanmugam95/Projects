package com.sh953454.foundation.bank.AccountTracker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sh953454.foundation.bank.AccountTracker.model.Account;
import com.sh953454.foundation.bank.AccountTracker.model.Customer;
import com.sh953454.foundation.bank.AccountTracker.model.Transaction;
import com.sh953454.foundation.bank.AccountTracker.service.AccountService;

@RestController
@RequestMapping("api")
public class BankController {
	
	@Autowired
	private AccountService accountServ;
	
	@GetMapping("/")
	public String showDefault() {
		return "New Spring app";
	}
	
	@GetMapping("/accounts")
	public List<Account> getAccounts() {
		return accountServ.getAllAccount();
	}
	
	@PostMapping(value="/addAccount",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> addNewAccount (@RequestBody Account newAccount) {
		Account insAccount = accountServ.addAccount(newAccount);
		if(insAccount==null) {
			return new ResponseEntity<>("NO_ACCOUNT_FOUND", HttpStatus.NO_CONTENT);
		}else {
			return new ResponseEntity<>(insAccount.getAccountNumber(), HttpStatus.OK);
		}
	}
	
	@PutMapping(value="/updateCustomerInfo",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> updateCustomerInfo(@RequestBody Account account) {
		Customer updAccount = accountServ.updateCustomer(account);
		if(updAccount == null) {
			return new ResponseEntity<>("INVALID_SEARCH_CRITERIA", HttpStatus.BAD_REQUEST);
		}else {
			return new ResponseEntity<>("ACCOUNT UPDATE SUCCESSFUL", HttpStatus.OK);
		}
	}
	
	@PostMapping(value="/transferFunds",consumes=MediaType.APPLICATION_JSON_VALUE,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public String transferFunds(@RequestBody Transaction transactionBean) {
		return accountServ.transferAmount(transactionBean.getSourceAccount(), transactionBean.getDestinationAccount(), transactionBean.getAmount());
	}
}
