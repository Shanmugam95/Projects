INSERT INTO bank_details.Account (id, account_number, account_type, account_holder_name, current_balance, branch_name)
VALUES (1, '7308463591', 'SA','Elon Musk' ,100710.78, 'Washington DC');
INSERT INTO bank_details.Customer (id, account_number, customer_name, phone_number, email_address, age, occupation)
VALUES (1, '7308463591', 'Elon Musk', '+55 578 5876','elon.musk@tesla.com' ,43, 'Private');
INSERT INTO bank_details.Account (id, account_number, account_type, account_holder_name, current_balance, branch_name)
VALUES (2, '2195620473', 'CR','Sundhar Pichai' ,67005.01, 'Silicon Valley');
INSERT INTO bank_details.Customer (id, account_number, customer_name, phone_number, email_address, age, occupation)
VALUES (2, '2195620473', 'Sundhar Pichai', '+235 7891 642','sundar.pichai@alpahabet.com' ,41, 'Private');

/*INSERT INTO online_bank.transaction (id, source_account_id, target_account_id, target_owner_name, amount, initiation_date, completion_date, reference)
VALUES (1, 1, 2, 'Scrooge McDuck', 100.00, '2019-04-01 10:30', '2019-04-01 10:54', 'Protection charge Apr');
INSERT INTO online_bank.transaction (id, source_account_id, target_account_id, target_owner_name, amount, initiation_date, completion_date, reference)
VALUES (2, 1, 2, 'Scrooge McDuck', 100.00, '2019-05-01 10:30', '2019-05-01 11:21', 'Protection charge May');

INSERT INTO online_bank.transaction (id, source_account_id, target_account_id, target_owner_name, amount, initiation_date, completion_date, reference)
VALUES (3, 2, 1, 'Paul Dragoslav', 10000.00, '2019-05-27 17:21', null, 'Ha Ha I am rich');*/
