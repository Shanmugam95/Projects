package com.sh953454.foundation.bank.AccountTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
