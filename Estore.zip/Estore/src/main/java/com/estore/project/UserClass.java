package com.estore.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.estore.project.bean.InvoiceListBean;
import com.estore.project.bean.LoginReqBean;
import com.estore.project.bean.VideoDetailsBean;

@RestController
public class UserClass {
	private static final String USERLIST_SESS = "userList";
	private static final String VIDEOLIST_SESS = "videoList";
	private static final String INVOLIST_SESS = "invoiceList";
	private static final String SUCC = "Success";
	private static final String FAIL = "Failure";
	private static final String UNAME = "userName";
	private static final String UEMAIL = "userEmail";
	
	@GetMapping(value="/login")
	public ModelAndView getLoginPage() {
		return new ModelAndView("Login");
	}
	
	@GetMapping(value="/logout")
	public ModelAndView getLogoutPage() {
		return new ModelAndView("Login");
	}
	
	@GetMapping(value="/register")
	public ModelAndView getRegisterPage() {
		return new ModelAndView("Register");
	}
	
	@GetMapping(value="/userhome")
	public ModelAndView getUserHomePage() {
		return new ModelAndView("Home");
	}
	
	@GetMapping(value="/checkout")
	public ModelAndView getCheckoutPage() {
		return new ModelAndView("Checkout");
	}
	
	@GetMapping(value="/ordercreation")
	public ModelAndView getCreateOrderPage() {
		return new ModelAndView("Createorder");
	}
	
	@GetMapping(value="/myaccount")
	public ModelAndView getMyAccPage() {
		return new ModelAndView("Myaccount");
	}
	
	@GetMapping(value="/adminhome")
	public ModelAndView getAdmHomePage() {
		return new ModelAndView("Adminhome");
	}
	
	@GetMapping(value="/addvideo")
	public ModelAndView getVideoPage() {
		return new ModelAndView("Addvideo");
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/loginAction",produces= MediaType.APPLICATION_JSON_VALUE)
	public List<String> getLoginDetails(@RequestBody LoginReqBean req,HttpSession session) {
		String user=req.getUserName();
		String passwd=req.getPassword();
		String retPage=FAIL;
		List<LoginReqBean> list = new ArrayList<>();
		List<String> resList=new ArrayList<>();
		if(null!=session.getAttribute(USERLIST_SESS)) {
			list = (List<LoginReqBean>) session.getAttribute(USERLIST_SESS);
		}
		resList.add("200");
		if("admin".equals(user)&&"admin@123".equals(passwd)) {
			retPage="Admin";
		}else {
			session.setAttribute(UNAME, user);
			
			for(LoginReqBean bean: list) {
				if(bean.getUserName().equalsIgnoreCase(user)&&bean.getPassword().equalsIgnoreCase(passwd)) {
					retPage="User";
					session.setAttribute(UEMAIL, bean.getEmailId());
					break;
				}
			}
		}
		resList.add(retPage);
		return resList;
	}
	@SuppressWarnings("unchecked")
	@PostMapping(value="/registerAction",produces= MediaType.ALL_VALUE)
	public List<String> setRegisterDetails(@RequestBody LoginReqBean req,HttpSession session) {
		String user=req.getUserName();
		String result=FAIL;
		boolean flag = false;
		List<String> resList = new ArrayList<>();
		List<LoginReqBean> list = new ArrayList<>();
		if(null!=session.getAttribute(USERLIST_SESS)) {
			list = (List<LoginReqBean>) session.getAttribute(USERLIST_SESS);
		}
		
		for(LoginReqBean bean : list) {
			if(bean.getUserName().equalsIgnoreCase(user)) {
				flag=true;
				break;
			}
		}
		if(!flag) {
			list.add(req);
			result=SUCC;
			session.setAttribute(UNAME, user);
			session.setAttribute(UEMAIL, req.getEmailId());
			session.setAttribute(USERLIST_SESS,list);
		}
		resList.add(result);
		return resList;
	}
	@SuppressWarnings("unchecked")
	@PostMapping(value="/getVideoList",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<VideoDetailsBean> getVideoList(HttpSession session){
		List<VideoDetailsBean> list = new ArrayList<>();
		if(null!=session.getAttribute(VIDEOLIST_SESS)) {
			list = (List<VideoDetailsBean>) session.getAttribute(VIDEOLIST_SESS);
		}
		return list;
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value="/deleteVideo",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<VideoDetailsBean> deleteVideoFromList(@RequestBody VideoDetailsBean req,HttpSession session){
		List<VideoDetailsBean> list = new ArrayList<>();
		if(null!=session.getAttribute(VIDEOLIST_SESS)) {
			list = (List<VideoDetailsBean>) session.getAttribute(VIDEOLIST_SESS);
		}
		Iterator<VideoDetailsBean> ir = list.iterator();
		while(ir.hasNext()) {
			VideoDetailsBean bean = ir.next();
			if(bean.getVideoName().equalsIgnoreCase(req.getVideoName())) {
				ir.remove();
				break;
			}
		}
		session.setAttribute(VIDEOLIST_SESS,list);
		return list;
	}
	@SuppressWarnings("unchecked")
	@PostMapping(value="/setOrder",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<String> setInvoice(@RequestBody InvoiceListBean req,HttpSession session){
		List<InvoiceListBean> list= new ArrayList<>();
		Map<String,List<InvoiceListBean>> map = new HashMap<>();
		List<String> resList = new ArrayList<>();
		String uName = (String) session.getAttribute(UNAME);
		if(null!=session.getAttribute(INVOLIST_SESS)) {
			map = (Map<String, List<InvoiceListBean>>) session.getAttribute(INVOLIST_SESS);
		}
		if(null!=map.get(uName)) {
		list = map.get(uName);
		}
		if(list.isEmpty()) {
			req.setInvoiceId("INV-1");
		}else {
			String id=list.get(list.size()-1).getInvoiceId();
			id = id.substring(4);
			int idV = Integer.parseInt(id)+1;
			String inv = "INV-"+idV;
			req.setInvoiceId(inv);
		}
		list.add(req);
		map.put(uName, list);
		session.setAttribute(INVOLIST_SESS, map);
		resList.add(SUCC);
		return resList;
	}
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@PostMapping(value="/getAccountDetails",produces=MediaType.APPLICATION_JSON_VALUE)
	public List getAccountDetails(HttpSession session) {
		List resList = new ArrayList();
		Map<String,List<InvoiceListBean>> map = new HashMap<>();
		List<InvoiceListBean> list;
		String uName = (String) session.getAttribute(UNAME);
		String emailId = (String) session.getAttribute(UEMAIL);
		if(null!=session.getAttribute(INVOLIST_SESS)) {
			map = (Map<String, List<InvoiceListBean>>) session.getAttribute(INVOLIST_SESS);
		}
		list = map.get(uName);
		resList.add(list);
		resList.add(uName);
		resList.add(emailId);
		return resList;
	}
	@SuppressWarnings("unchecked")
	@PostMapping(value="/adminAction",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<String> getUserList(@RequestBody VideoDetailsBean req,HttpSession session) {
		String name = req.getVideoName();
		String result = FAIL;
		List<String> resList = new ArrayList<>();
		List<VideoDetailsBean> list = new ArrayList<>();
		int prodId;
		boolean flag = false;
		if(null!=session.getAttribute(VIDEOLIST_SESS)) {
			list = (List<VideoDetailsBean>) session.getAttribute(VIDEOLIST_SESS);
		}
		if(list.isEmpty()) {
			prodId=1;
		}else {
			prodId=list.get(list.size()-1).getProductId()+1;
		}
		for(VideoDetailsBean bean : list) {
			if(bean.getVideoName().equalsIgnoreCase(name)) {
				flag=true;
				break;
			}
		}
		if(!flag) {
			req.setProductId(prodId);
			list.add(req);
			result=SUCC;
			session.setAttribute(VIDEOLIST_SESS,list);
		}
		resList.add(result);
		return resList;
	}

}
