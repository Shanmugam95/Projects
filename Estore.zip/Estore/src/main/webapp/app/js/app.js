var app = angular.module("app",[]);
app.controller("loginCtrl",function($rootScope,$scope,$http){
	var loginurl = "loginAction";
	$scope.error="";
	$scope.loginCall = function(){
		$scope.error="";
		var chkOut =[];
		sessionStorage.setItem("basket","0 video(s) $0.0");
		sessionStorage.setItem("chkOut",JSON.stringify(chkOut));
		var dataObj = {
				"userName":$scope.username,
				"password":$scope.password
		}
		$http({
			method:"POST",
			url:loginurl,
			data:dataObj
		}).then(function successCallback(response){
			console.log(response.data);
			if(response.data[1]=="Admin"){
				window.location="adminhome";
			}else if(response.data[1]=="User"){
				window.location="userhome";
			}else{
				$scope.error="Invalid Credentials";
			}
		});
	};

});
app.controller("registerCtrl",function($rootScope,$scope,$http){
	$scope.error="";
	var registerurl = "registerAction";
	$scope.regCall = function(){
		$scope.error="";
		var namReg = /^[a-zA-Z0-9]{3,30}$/;
		var pwdReg = /^.{3,30}$/;
		var emailReg = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
		var name = $("#userName").val();
		var pwd = $("#password").val();
		var cfpwd = $("#confirmPassword").val();
		var email = $("#email").val();
		if(!namReg.test(name)||!pwdReg.test(pwd)||!pwdReg.test(cfpwd)||!emailReg.test(email)||(pwd!=cfpwd)){
			$scope.error="Invalid data";
			return false;
		}
		var dataObj = {
				"userName": name,
				"password": pwd,
				"emailId" : email
		}
		$http({
			method:"POST",
			url:registerurl,
			data:dataObj
		}).then(function successCallback(response){
			console.log(response.data);
			if(response.data[0]=="Success"){
				var chkOut =[];
				sessionStorage.setItem("basket","0 video(s) $0.0");
				sessionStorage.setItem("chkOut",JSON.stringify(chkOut));
				window.location="login";
			}else{
				$scope.error="Invalid data";
			}
		});
	};
	
});
app.controller("addVdCtrl",function($rootScope,$scope,$http){
	$scope.error="";
	$scope.videoname=""; $scope.price="";
	var addVdurl = "adminAction";
	$scope.addCall = function(){
		var namReg = /^.{5,}$/;
		var priceReg = /^[0-9]{1,4}(\.[0-9]+)?$/; /*/^[0-9]{1,4}$/;*/
		var name = $("#name").val();
		var desc = $("#description").val();
		var price = $("#price").val();
		if(!namReg.test(name)||!priceReg.test(price)){
			$scope.error="Invalid data";
			return false;
		}
		var dataObj = {
				"videoName": name,
				"videoDesc": desc,
				"price" : price
		}
		$http({
			method:"POST",
			url:addVdurl,
			data:dataObj
		}).then(function successCallback(response){
			console.log(response.data);
			if(response.data[0]=="Success"){
				window.location="adminhome";
			}else{
				$scope.error="Invalid data";
			}
		});
	};
	
});
app.controller("chkOutCtrl",function($rootScope,$scope,$http){
	var chkL = sessionStorage.getItem("chkOut");
	$scope.chkList = JSON.parse(chkL);
	$scope.basketAmt = sessionStorage.getItem("basket");
	var bask = $scope.basketAmt.split(" ");
	$scope.totAmt = parseFloat(bask[2].substring(1));
	$scope.message = "";
	$scope.chkTab=true;
	if($scope.chkList.length==0){
		$scope.chkTab=false;
		$scope.message="Cart is empty";}
	$scope.removeCart= function(v){
		var bask = $scope.basketAmt;
		var index = $scope.chkList.indexOf(v);
		$scope.chkList.splice(index,1);
		sessionStorage.setItem("chkOut",JSON.stringify($scope.chkList));
		if($scope.chkList.length==0){
			$scope.chkTab=false;
			$scope.message="Cart is empty";}
		var baskArr = bask.split(" ");
		var num = parseInt(baskArr[0])-v.quantity;
		var amt = parseFloat(baskArr[2].substring(1))-parseFloat(v.price*v.quantity);
		$scope.basketAmt = String(num)+" video(s) $"+String(amt);
		$scope.totAmt = amt;
		sessionStorage.setItem("basket",$scope.basketAmt);
	}
});
app.controller("orderCtrl",function($rootScope,$scope,$http){
	var orderurl = "setOrder";
	$scope.basketAmt = sessionStorage.getItem("basket");
	var baskArr = $scope.basketAmt.split(" ");
	var item = parseInt(baskArr[0]);
	var price = parseFloat(baskArr[2].substring(1));
	$scope.error = "";
	$scope.orderCall = function(){
		$scope.error = "";
		var namReg = /^[a-zA-Z0-9 ]{5,30}$/;
		var adrReg = /^.{5,30}$/;
		var pinCReg = /^[0-9]{5,6}$/;
		var name = $("#name").val();
		var city = $("#city").val();
		var country = $("#country").val();
		var address = $("#address").val();
		var pinC = $("#pinCode").val();
		if(!namReg.test(name)||!namReg.test(city)||!namReg.test(country)||!adrReg.test(address)||!pinCReg.test(pinC)){
			$scope.error = "Invalid data";
			return false;
		}
		var dataObj = {
				"item":item,
				"price":price
		}
		$http({
			method:"POST",
			url:orderurl,
			data:dataObj
		}).then(function successCallback(response){
			console.log(response.data);
			if(response.data[0]=="Success"){
				var chkOut =[];
				sessionStorage.setItem("basket","0 video(s) $0.0");
				$scope.basketAmt = "0 video(s) $0.0";
				sessionStorage.setItem("chkOut",JSON.stringify(chkOut));
				$scope.error="Order placed successfully";
			}else{
				$scope.error="Invalid data";
			}
		});
	}
});
app.controller("accCtrl",function($rootScope,$scope,$http){
	var accounturl = "getAccountDetails";
	$scope.message="";
	$scope.invTab=true;
	$scope.basketAmt = sessionStorage.getItem("basket");
	$http({
		method:"POST",
		url:accounturl,
	}).then(function successCallback(response){
		console.log(response.data);
		$scope.invList = response.data[0];
		$scope.name = response.data[1];
		$scope.email = response.data[2];
		if($scope.invList==null){
			$scope.invTab=false;
			$scope.message="No orders to display";	
		}
	});
});