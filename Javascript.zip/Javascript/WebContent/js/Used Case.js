function valid(){
	var email=document.getElementById("eid").value;
	var aler=document.getElementById("alert");
	var regex=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	if(regex.test(email)){
	  aler.style.visibility='hidden';
	  return true;
	}else{
	 aler.style.visibility='visible';
	 return false;
}
}